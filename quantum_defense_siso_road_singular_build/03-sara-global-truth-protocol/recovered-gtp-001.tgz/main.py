
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import FastAPI
from pydantic import BaseModel, Field

PROTOCOL_ID = "SARA-GTP-001"
PROTOCOL_NAME = "SARA Global Truth Protocol"

app = FastAPI(
    title=PROTOCOL_NAME,
    version="1.0.0",
    description="Global anti-hallucination, anti-fluff, anti-fabrication governance layer for SARA."
)

class TruthCheckRequest(BaseModel):
    module_id: str = Field(default="unknown")
    user_directive: str = Field(default="")
    proposed_response: str = Field(default="")
    evidence: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    context: Optional[str] = None
    requires_current_facts: bool = False
    requires_action: bool = False

class TruthCheckResponse(BaseModel):
    protocol_id: str
    protocol_name: str
    status: str
    allowed: bool
    timestamp: str
    module_id: str
    violations: list[str]
    required_corrections: list[str]
    context_verification: str
    assumption_disclosure: list[str]
    uncertainty_statement_required: bool
    clarification_required: bool
    clarification_questions: list[str]
    final_instruction: str

GLOBAL_RULES = [
    "Hallucinations are prohibited.",
    "Lies and fabricated facts are prohibited.",
    "Unsupported certainty is prohibited.",
    "Fluff, filler, and evasive language are prohibited.",
    "If evidence is missing, say what is unknown.",
    "If current facts are required, live verification is required before specific claims.",
    "If ambiguity exists, ask for clarification before action.",
    "If assumptions are required, disclose them before proceeding.",
    "If an error is identified, acknowledge it immediately and correct it.",
    "Every significant SARA action must preserve auditability."
]

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

def detect_violations(req: TruthCheckRequest):
    text = (req.proposed_response or "").strip()
    directive = (req.user_directive or "").strip()

    violations = []
    corrections = []
    questions = []

    if not text:
        violations.append("EMPTY_RESPONSE")
        corrections.append("Provide a direct, grounded response or ask a specific clarification question.")

    vague_phrases = [
        "it seems", "might be", "possibly", "perhaps", "as an ai",
        "i think", "probably", "could be", "in general terms"
    ]

    if text:
        vague_count = sum(1 for p in vague_phrases if p in text.lower())
        if vague_count >= 3:
            violations.append("EXCESSIVE_VAGUENESS_OR_FLUFF")
            corrections.append("Remove filler and state only verified facts, explicit assumptions, or clear uncertainty.")

    false_certainty_phrases = [
        "guaranteed", "certainly", "undeniably", "without question",
        "definitely true", "proven"
    ]

    if any(p in text.lower() for p in false_certainty_phrases) and not req.evidence:
        violations.append("UNSUPPORTED_CERTAINTY")
        corrections.append("Remove certainty or attach evidence. Use uncertainty language when evidence is absent.")

    if req.requires_current_facts and not req.evidence:
        violations.append("CURRENT_FACTS_WITHOUT_LIVE_EVIDENCE")
        corrections.append("Perform live verification or state that current facts require verification before quoting specifics.")

    if req.requires_action and not directive:
        violations.append("ACTION_WITHOUT_DIRECTIVE")
        corrections.append("Do not act without a clear directive.")

    ambiguous_directives = ["fix it", "do it", "build this", "run it", "deploy it", "make it work"]
    if directive.lower() in ambiguous_directives or (directive and len(directive.split()) < 4 and req.requires_action):
        violations.append("AMBIGUOUS_DIRECTIVE")
        corrections.append("Ask for the target service, file, or deployment path before acting.")
        questions.append("Which exact service, file, or module should this action target?")

    if "medical advice" in text.lower() and "pharma" in directive.lower():
        violations.append("OVERBROAD_MEDICAL_REFUSAL_RISK")
        corrections.append("Do not refuse company-level pharma R&D analysis as patient medical advice.")

    return violations, corrections, questions

def evaluate(req: TruthCheckRequest) -> TruthCheckResponse:
    violations, corrections, questions = detect_violations(req)

    assumptions = req.assumptions or [
        "No hidden assumptions may be used. If an assumption is needed, it must be stated first."
    ]

    clarification_required = "AMBIGUOUS_DIRECTIVE" in violations

    allowed = not bool(violations)
    status = "truth_protocol_passed" if allowed else "blocked_until_corrected"

    return TruthCheckResponse(
        protocol_id=PROTOCOL_ID,
        protocol_name=PROTOCOL_NAME,
        status=status,
        allowed=allowed,
        timestamp=now(),
        module_id=req.module_id,
        violations=violations,
        required_corrections=corrections,
        context_verification=req.context or (
            "Global SARA ecosystem context: all modules must operate under truth, evidence, clarity, and auditability constraints."
        ),
        assumption_disclosure=assumptions,
        uncertainty_statement_required=bool(req.requires_current_facts and not req.evidence),
        clarification_required=clarification_required,
        clarification_questions=questions,
        final_instruction=(
            "Proceed only with grounded, factual, non-fluffy output."
            if allowed else
            "Do not proceed until violations are corrected."
        ),
    )

@app.get("/")
def root() -> dict[str, Any]:
    return {
        "status": "ok",
        "service": "sara-global-truth-protocol",
        "protocol_id": PROTOCOL_ID,
        "routes": ["/health", "/manifest", "/truth/check", "/truth/rules"],
    }

@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "service": "sara-global-truth-protocol",
        "protocol_id": PROTOCOL_ID,
        "timestamp": now(),
    }

@app.get("/manifest")
def manifest() -> dict[str, Any]:
    return {
        "protocol_id": PROTOCOL_ID,
        "name": PROTOCOL_NAME,
        "scope": "GLOBAL_SARA_ECOSYSTEM",
        "status": "ACTIVE",
        "strictly_prohibited": [
            "hallucinations",
            "lies",
            "fabricated facts",
            "unsupported certainty",
            "fluff",
            "false refusals",
            "hidden assumptions",
            "ambiguous action without clarification",
        ],
        "required_behavior": [
            "verify context",
            "state assumptions",
            "ask clarification when ambiguous",
            "state uncertainty when evidence is missing",
            "correct errors immediately",
            "preserve auditability",
        ],
        "timestamp": now(),
    }

@app.get("/truth/rules")
def truth_rules() -> dict[str, Any]:
    return {
        "protocol_id": PROTOCOL_ID,
        "rules": GLOBAL_RULES,
    }

@app.post("/truth/check")
def truth_check(req: TruthCheckRequest) -> TruthCheckResponse:
    return evaluate(req)
