import os
import requests

GAF_URL = os.getenv("SARA_GAF_FUSION_URL", "").rstrip("/")
GAF_REQUIRED = os.getenv("SARA_GAF_FUSION_REQUIRED", "false").lower() == "true"
AUTHORITY_CONTEXT = (
    "SARA full-stack authority: current_count=184; live_cloud_run_count=184; "
    "qcr_locked=true; source_of_truth=SARA-QCR-001 fallback full-stack live Cloud Run count; "
    "legacy_firestore_count=107 superseded; nexus_count_is_subset=true; "
    "nexus_count_authoritative_for_full_stack=false; "
    "scme_smrrs_role=verification_registry_not_full_stack_count_authority; "
    "gaf_firewall_name=SARA-GAF-FUSION-002; "
    "gaf_cloud_run_service=sara-gaf-fusion-ecosystem; "
    "gaf_full_name=SARA Generative Accuracy Firewall Fusion Ecosystem."
)

def gaf_verify_text(prompt: str, text: str, output_domain: str = "sara_api") -> str:
    if not text:
        return text
    if not GAF_URL:
        if GAF_REQUIRED:
            return "[BLOCKED: SARA-GAF-FUSION-002 required but SARA_GAF_FUSION_URL is missing.]"
        return text
    payload = {
        "prompt": prompt or "",
        "draft_answer": text,
        "context": AUTHORITY_CONTEXT,
        "evidence": [{"source_id": "sara-qcr-authority-env", "text": AUTHORITY_CONTEXT, "reliability": 0.98}],
        "output_domain": output_domain,
        "allow_remediation": True,
        "strict": True,
    }
    try:
        r = requests.post(f"{GAF_URL}/v1/verify", json=payload, timeout=20)
        r.raise_for_status()
        data = r.json()
        return data.get("remediated_answer") or text
    except Exception:
        return text

def gaf_enforce_payload(payload, prompt: str = "sara output", output_domain: str = "sara_api"):
    text_keys = {"response", "answer", "reply", "message", "text", "content", "summary", "analysis", "report", "recommendation", "result", "output", "final", "decision", "status", "detail", "sara_summary"}
    if isinstance(payload, dict):
        patched = dict(payload)
        for key, val in list(patched.items()):
            if key in text_keys and isinstance(val, str) and val.strip():
                patched[key] = gaf_verify_text(f"{prompt}:{key}", val, output_domain)
            elif isinstance(val, dict):
                patched[key] = gaf_enforce_payload(val, f"{prompt}:{key}", output_domain)
            elif isinstance(val, list):
                patched[key] = [gaf_enforce_payload(x, f"{prompt}:{key}", output_domain) if isinstance(x, dict) else x for x in val]
        return patched
    if isinstance(payload, str) and payload.strip():
        return gaf_verify_text(prompt, payload, output_domain)
    return payload
