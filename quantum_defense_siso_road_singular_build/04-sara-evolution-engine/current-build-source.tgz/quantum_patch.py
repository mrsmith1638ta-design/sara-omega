import hashlib
import json
import os
import time
from typing import Optional
from pydantic import BaseModel

PATCH_VERSION = "SARA-QUANTUM-DEFENSE-ALT-001-IMPL-v1.3"

ALGORITHM_STATUS = {
    "CRYSTALS-Kyber-1024": {"decision": "CURRENT", "nist_status": "standardized", "attack_surface": "kem_lattice_module_lwe"},
    "CRYSTALS-Dilithium-L5": {"decision": "CURRENT", "nist_status": "standardized", "attack_surface": "signature_module_lattice"},
    "ChaCha20-Poly1305": {"decision": "CURRENT", "nist_status": "symmetric_aead", "attack_surface": "grover_reduced_margin_acceptable_with_256_bit_key"},
    "SHA3-512": {"decision": "CURRENT", "nist_status": "hash_standard", "attack_surface": "grover_margin_512_bit_output"},
}

_RECOMMENDATIONS = []

class AlgorithmRequest(BaseModel):
    algorithm: Optional[str] = None
    name: Optional[str] = None
    reason: Optional[str] = None

def _hash(data) -> str:
    payload = json.dumps(data, sort_keys=True, default=str).encode()
    return hashlib.sha3_512(payload).hexdigest()

def _decision_for(name: str) -> dict:
    normalized = (name or "").strip()
    known = ALGORITHM_STATUS.get(normalized)
    if known:
        return {"algorithm": normalized, **known}
    return {"algorithm": normalized or "unknown", "decision": "MONITOR", "nist_status": "unknown_or_untracked", "attack_surface": "requires_manual_review"}

def _append_recommendation(entry: dict):
    _RECOMMENDATIONS.append(entry)
    del _RECOMMENDATIONS[:-100]
    try:
        from google.cloud import firestore  # type: ignore
        project = os.environ.get("GCP_PROJECT") or os.environ.get("PROJECT_ID")
        collection = os.environ.get("SARA_QUANTUM_FABRIC_COLLECTION", "sara_crypto_recommendations")
        client = firestore.Client(project=project) if project else firestore.Client()
        client.collection(collection).document(entry["recommendation_id"]).set(entry)
    except Exception:
        pass

def register_quantum_fabric(app):
    @app.post("/v1/quantum/assess-algorithm")
    def assess_algorithm(body: AlgorithmRequest):
        name = body.algorithm or body.name or ""
        return {
            "service": "sara-evolution-engine",
            "patch": PATCH_VERSION,
            "assessment": _decision_for(name),
            "source": "static_versioned_quantum_attack_database",
            "external_api_calls": False,
        }

    @app.get("/v1/quantum/fabric-status")
    def fabric_status():
        return {
            "service": "sara-evolution-engine",
            "status": "operational",
            "patch": PATCH_VERSION,
            "suite": ALGORITHM_STATUS,
            "ppsim_url": os.environ.get("SARA_PQC_PPSIM_URL", ""),
            "recommendation_collection": os.environ.get("SARA_QUANTUM_FABRIC_COLLECTION", "sara_crypto_recommendations"),
        }

    @app.post("/v1/quantum/recommend-update")
    def recommend_update(body: AlgorithmRequest):
        assessment = _decision_for(body.algorithm or body.name or "")
        entry = {
            "recommendation_id": "QREC-" + str(int(time.time())),
            "timestamp_epoch": int(time.time()),
            "algorithm": assessment["algorithm"],
            "decision": assessment["decision"],
            "reason": body.reason or assessment["attack_surface"],
            "patch": PATCH_VERSION,
        }
        entry["entry_hash_sha3_512"] = _hash(entry)
        _append_recommendation(entry)
        return {"accepted": True, **entry}

    return app
