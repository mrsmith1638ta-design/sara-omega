import logging
from flask import Flask, jsonify

logger = logging.getLogger("sara-evolution-engine.main_patched")

try:
    from main import app  # type: ignore
    logger.info("Loaded base app from main:app")
except Exception as exc:
    app = Flask(__name__)

    @app.get("/health")
    def health():
        return jsonify({
            "service": "sara-evolution-engine",
            "status": "operational",
            "patch": "quantum-defense-v13",
        })

    logger.warning("Base main:app unavailable; using fallback app: %s", exc)

from quantum_patch import register_quantum_fabric

register_quantum_fabric(app)
