import logging
from flask import Flask, jsonify

logger = logging.getLogger("raft-node.main_patched")

try:
    from main import app  # type: ignore
    logger.info("Loaded base app from main:app")
except Exception as exc:
    app = Flask(__name__)

    @app.get("/health")
    def health():
        return jsonify({
            "service": "raft-node",
            "status": "operational",
            "patch": "quantum-defense-v13",
        })

    logger.warning("Base main:app unavailable; using fallback app: %s", exc)

from raft_pqc_patch import register_raft_pqc

register_raft_pqc(app)
