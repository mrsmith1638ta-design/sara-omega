import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from flask import jsonify, request


PATCH_VERSION = "SARA-QUANTUM-DEFENSE-ALT-001-IMPL-v1.3"
_ACCEPTED_VOTES = []


def _identity_token(audience: str) -> str:
    url = (
        "http://metadata.google.internal/computeMetadata/v1/instance/"
        "service-accounts/default/identity?audience="
        + urllib.parse.quote(audience.rstrip("/"), safe="")
    )
    req = urllib.request.Request(url, headers={"Metadata-Flavor": "Google"})
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.read().decode("utf-8")
    except Exception:
        return ""


def _verify_signature(message, signature: str) -> tuple[int, dict]:
    base_url = os.environ.get("SARA_PQC_PPSIM_URL", "")
    if not base_url:
        return 500, {"error": "missing_SARA_PQC_PPSIM_URL"}
    token = _identity_token(base_url)
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(
        base_url.rstrip("/") + "/v1/pqc/verify",
        data=json.dumps({"message": message, "signature": signature}).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            payload = resp.read().decode("utf-8") or "{}"
            return resp.status, json.loads(payload)
    except urllib.error.HTTPError as exc:
        return exc.code, {"error": "http_error", "detail": exc.read().decode("utf-8", errors="replace")}
    except Exception as exc:
        return 503, {"error": "call_failed", "detail": str(exc)}


def _strict() -> bool:
    return os.environ.get("SARA_PQC_CONSENSUS_STRICT", "false").lower() == "true"


def register_raft_pqc(app):
    @app.get("/v1/consensus/pqc-status")
    def pqc_status():
        return jsonify({
            "service": os.environ.get("K_SERVICE", "raft-node"),
            "node_id": os.environ.get("NODE_ID", ""),
            "status": "operational",
            "patch": PATCH_VERSION,
            "pqc_consensus_strict": _strict(),
            "ppsim_url": os.environ.get("SARA_PQC_PPSIM_URL", ""),
            "accepted_vote_count": len(_ACCEPTED_VOTES),
        })

    @app.post("/v1/consensus/pqc-vote")
    def pqc_vote():
        body = request.get_json(silent=True) or {}
        vote = body.get("vote") or body
        signature = str(body.get("signature") or "")
        if signature:
            verify_status, verified = _verify_signature(vote, signature)
            valid = bool(verified.get("valid"))
            if not valid:
                return jsonify({
                    "accepted": False,
                    "reason": "invalid_pqc_signature",
                    "verify_status": verify_status,
                    "verify_response": verified,
                }), 403
        elif _strict():
            return jsonify({"accepted": False, "reason": "missing_pqc_signature_strict_mode"}), 403
        else:
            verify_status, verified, valid = 0, {"migration_mode": True}, True

        entry = {
            "node_id": os.environ.get("NODE_ID", ""),
            "timestamp_epoch": int(time.time()),
            "signed": bool(signature),
            "vote_term": body.get("term"),
            "candidate_id": body.get("candidate_id"),
        }
        _ACCEPTED_VOTES.append(entry)
        del _ACCEPTED_VOTES[:-100]
        return jsonify({
            "accepted": valid,
            "strict": _strict(),
            "verify_status": verify_status,
            "verify_response": verified,
            "entry": entry,
        })

    return app
